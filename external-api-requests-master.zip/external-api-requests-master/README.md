## Service for External Requests
- Get AFPI API for storing Borrower's History that will be inserted into Mentor Reboot Database.